"""
QuantAlpha Trading Platform - Render Edition
Single-file deployment: FastAPI + Inline Dashboard
"""

from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import random
import json
from datetime import datetime, timedelta

app = FastAPI(title="QuantAlpha API", version="3.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ═══════════════════════════════════════════════════════════════
# MOCK DATA
# ═══════════════════════════════════════════════════════════════

SIGNALS = [
    {"symbol": "BTC/USDT", "market": "crypto", "direction": "LONG", "score": 87, "entry": 67234.50, "sl": 65800.00, "tp": 69800.00, "rr": 2.1, "confidence": "HIGH", "timeframe": "1h", "timestamp": "2025-01-15T14:30:00Z"},
    {"symbol": "ETH/USDT", "market": "crypto", "direction": "LONG", "score": 76, "entry": 3456.20, "sl": 3380.00, "tp": 3620.00, "rr": 2.3, "confidence": "HIGH", "timeframe": "4h", "timestamp": "2025-01-15T14:00:00Z"},
    {"symbol": "SOL/USDT", "market": "crypto", "direction": "SHORT", "score": 72, "entry": 148.20, "sl": 152.50, "tp": 140.00, "rr": 1.9, "confidence": "MEDIUM", "timeframe": "1h", "timestamp": "2025-01-15T14:15:00Z"},
    {"symbol": "AAPL", "market": "stocks", "direction": "SHORT", "score": 68, "entry": 189.50, "sl": 193.00, "tp": 183.00, "rr": 1.8, "confidence": "MEDIUM", "timeframe": "1d", "timestamp": "2025-01-15T09:30:00Z"},
    {"symbol": "EUR/USD", "market": "forex", "direction": "LONG", "score": 64, "entry": 1.0845, "sl": 1.0800, "tp": 1.0920, "rr": 1.7, "confidence": "MEDIUM", "timeframe": "1h", "timestamp": "2025-01-15T14:00:00Z"},
    {"symbol": "NVDA", "market": "stocks", "direction": "LONG", "score": 81, "entry": 875.30, "sl": 845.00, "tp": 920.00, "rr": 1.5, "confidence": "HIGH", "timeframe": "1d", "timestamp": "2025-01-15T09:30:00Z"},
    {"symbol": "XAU/USD", "market": "forex", "direction": "LONG", "score": 59, "entry": 2056.40, "sl": 2040.00, "tp": 2080.00, "rr": 1.4, "confidence": "LOW", "timeframe": "4h", "timestamp": "2025-01-15T12:00:00Z"},
    {"symbol": "LINK/USDT", "market": "crypto", "direction": "SHORT", "score": 53, "entry": 14.85, "sl": 15.30, "tp": 13.90, "rr": 2.1, "confidence": "LOW", "timeframe": "1h", "timestamp": "2025-01-15T13:45:00Z"},
]

MARKET_DATA = {
    "BTC/USDT": {"price": 67234.50, "change_24h": 2.34, "volume_24h": 28500000000, "high_24h": 68100.00, "low_24h": 65400.00},
    "ETH/USDT": {"price": 3456.20, "change_24h": 1.87, "volume_24h": 15200000000, "high_24h": 3520.00, "low_24h": 3380.00},
    "SOL/USDT": {"price": 148.20, "change_24h": -3.12, "volume_24h": 3200000000, "high_24h": 152.50, "low_24h": 145.00},
    "AAPL": {"price": 189.50, "change_24h": -0.82, "volume_24h": 45200000, "high_24h": 191.20, "low_24h": 188.00},
    "EUR/USD": {"price": 1.0845, "change_24h": 0.15, "volume_24h": 125000000000, "high_24h": 1.0860, "low_24h": 1.0820},
    "NVDA": {"price": 875.30, "change_24h": 3.45, "volume_24h": 38500000, "high_24h": 882.00, "low_24h": 860.00},
}

EQUITY_CURVE = [
    10000, 10045, 10020, 10080, 10150, 10120, 10200, 10280, 10350, 10320,
    10400, 10450, 10520, 10480, 10600, 10720, 10680, 10750, 10800, 10760,
    10850, 10920, 10880, 11000, 11050, 11100, 11060, 11150, 11200, 11180,
    11250, 11300, 11260, 11350, 11400, 11380, 11450, 11500, 11460, 11520,
    11580, 11600, 11550, 11620, 11680, 11700, 11650, 11720, 11780, 11800,
    11750, 11820, 11860, 11800, 11850, 11900, 11860, 11920, 11960, 11860,
]

# ═══════════════════════════════════════════════════════════════
# API ENDPOINTS
# ═══════════════════════════════════════════════════════════════

@app.get("/")
def root():
    return {"message": "QuantAlpha API", "status": "ok", "version": "3.0.0", "docs": "/docs"}

@app.get("/health")
def health():
    return {"status": "ok", "redis": "connected", "timestamp": datetime.utcnow().isoformat() + "Z"}

@app.get("/api/signals")
def get_signals(market: str = None):
    if market:
        return [s for s in SIGNALS if s["market"] == market.lower()]
    return SIGNALS

@app.get("/api/indicators")
def get_indicators(symbol: str = "BTC/USDT"):
    base = {"symbol": symbol.upper()}
    if "BTC" in symbol.upper():
        base.update({"rsi": 58.4, "macd": 0.024, "macd_signal": 0.018, "atr": 142.6, "vwap": 67120, "ema_20": 66950, "ema_50": 65800, "bollinger_upper": 68500, "bollinger_lower": 65800})
    elif "ETH" in symbol.upper():
        base.update({"rsi": 62.1, "macd": 0.031, "macd_signal": 0.025, "atr": 8.4, "vwap": 3450, "ema_20": 3440, "ema_50": 3380, "bollinger_upper": 3520, "bollinger_lower": 3380})
    elif "SOL" in symbol.upper():
        base.update({"rsi": 42.3, "macd": -0.015, "macd_signal": -0.008, "atr": 4.2, "vwap": 150, "ema_20": 151, "ema_50": 155, "bollinger_upper": 155, "bollinger_lower": 143})
    else:
        base.update({"rsi": round(35 + random.random() * 40, 1), "macd": round(random.random() * 0.05 - 0.025, 4), "macd_signal": round(random.random() * 0.03 - 0.015, 4), "atr": round(50 + random.random() * 100, 1), "vwap": round(100 + random.random() * 1000, 2), "ema_20": round(100 + random.random() * 1000, 2), "ema_50": round(100 + random.random() * 1000, 2), "bollinger_upper": round(120 + random.random() * 1100, 2), "bollinger_lower": round(80 + random.random() * 900, 2)})
    return base

@app.post("/api/backtest")
def run_backtest():
    return {
        "total_trades": 156,
        "winning_trades": 97,
        "losing_trades": 59,
        "win_rate": 0.623,
        "profit_factor": 1.94,
        "sharpe_ratio": 1.84,
        "max_drawdown_pct": 0.082,
        "total_return_pct": 0.186,
        "avg_trade_return": 0.119,
        "avg_win": 0.342,
        "avg_loss": 0.189,
        "equity_curve": EQUITY_CURVE,
        "monthly_returns": {"Jan": 3.2, "Feb": 2.1, "Mar": -1.4, "Apr": 4.5, "May": 2.8, "Jun": 3.1, "Jul": -0.8, "Aug": 5.2, "Sep": 1.9, "Oct": -2.3, "Nov": 3.7, "Dec": 2.4},
        "trades_distribution": {"0-1R": 45, "1-2R": 38, "2-3R": 22, "3R+": 10, "-1-0R": 28, "-2--1R": 18, "-2R+": 13}
    }

@app.get("/api/market-data")
def get_market_data():
    return MARKET_DATA


# ═══════════════════════════════════════════════════════════════
# DASHBOARD HTML
# ═══════════════════════════════════════════════════════════════

DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>QuantAlpha - Dashboard</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#0a0e1a;--bg2:#111827;--bg3:#1a2332;--accent:#00e5a0;--accent2:#00b4d8;--danger:#ff4757;--warning:#ffa502;--text:#e0e6ed;--text2:#8899a6;--border:#1e293b}
body{font-family:'Segoe UI',system-ui,-apple-system,sans-serif;background:var(--bg);color:var(--text);min-height:100vh}
.header{background:linear-gradient(135deg,var(--bg2) 0%,var(--bg3) 100%);border-bottom:1px solid var(--border);padding:1rem 2rem;display:flex;justify-content:space-between;align-items:center;position:sticky;top:0;z-index:100}
.logo{font-size:1.5rem;font-weight:800;background:linear-gradient(135deg,var(--accent),var(--accent2));-webkit-background-clip:text;-webkit-text-fill-color:transparent;letter-spacing:-1px}
.status{display:flex;align-items:center;gap:.5rem;font-size:.85rem;color:var(--accent)}
.status-dot{width:8px;height:8px;border-radius:50%;background:var(--accent);animation:pulse 2s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
.nav{display:flex;gap:.5rem;background:var(--bg2);padding:.5rem;border-radius:12px}
.nav button{padding:.6rem 1.2rem;border:none;border-radius:8px;background:transparent;color:var(--text2);cursor:pointer;font-weight:600;font-size:.9rem;transition:all .2s}
.nav button.active{background:linear-gradient(135deg,var(--accent),var(--accent2));color:#000}
.nav button:hover:not(.active){color:var(--text);background:var(--bg3)}
.container{max-width:1400px;margin:0 auto;padding:2rem}
.section{display:none;animation:fadeIn .4s ease}
.section.active{display:block}
@keyframes fadeIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1rem;margin-bottom:2rem}
.stat-card{background:linear-gradient(135deg,var(--bg2),var(--bg3));border:1px solid var(--border);border-radius:16px;padding:1.5rem;transition:transform .2s,border-color .2s}
.stat-card:hover{transform:translateY(-2px);border-color:var(--accent)}
.stat-label{font-size:.8rem;text-transform:uppercase;letter-spacing:1px;color:var(--text2);margin-bottom:.5rem}
.stat-value{font-size:2rem;font-weight:800}
.stat-value.green{color:var(--accent)}.stat-value.red{color:var(--danger)}.stat-value.blue{color:var(--accent2)}
.stat-sub{font-size:.85rem;color:var(--text2);margin-top:.25rem}
.grid-2{display:grid;grid-template-columns:repeat(auto-fit,minmax(400px,1fr));gap:1.5rem}
.card{background:var(--bg2);border:1px solid var(--border);border-radius:16px;padding:1.5rem}
.card h3{font-size:1.1rem;margin-bottom:1rem;display:flex;align-items:center;gap:.5rem}
.card h3::before{content:"";width:4px;height:20px;background:linear-gradient(135deg,var(--accent),var(--accent2));border-radius:2px}
#equityChart,#backtestChart{width:100%;height:280px}
table{width:100%;border-collapse:collapse;font-size:.9rem}
th{text-align:left;padding:.75rem;color:var(--text2);font-weight:600;font-size:.8rem;text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--border)}
td{padding:.75rem;border-bottom:1px solid var(--border)}
tr:hover td{background:rgba(0,229,160,.05)}
.badge{padding:.25rem .6rem;border-radius:6px;font-size:.75rem;font-weight:700;text-transform:uppercase}
.badge-long{background:rgba(0,229,160,.15);color:var(--accent)}
.badge-short{background:rgba(255,71,87,.15);color:var(--danger)}
.badge-high{background:rgba(0,229,160,.15);color:var(--accent)}
.badge-medium{background:rgba(255,165,2,.15);color:var(--warning)}
.badge-low{background:rgba(136,153,166,.15);color:var(--text2)}
.score-bar{height:6px;background:var(--bg3);border-radius:3px;overflow:hidden;width:80px}
.score-fill{height:100%;border-radius:3px;transition:width .5s ease}
.score-fill.high{background:linear-gradient(90deg,var(--accent),var(--accent2))}
.score-fill.medium{background:linear-gradient(90deg,var(--warning),#ff6b35)}
.score-fill.low{background:linear-gradient(90deg,var(--danger),#ff6348)}
.metric-row{display:flex;justify-content:space-between;padding:.75rem 0;border-bottom:1px solid var(--border)}
.metric-row:last-child{border:none}
.metric-label{color:var(--text2);font-size:.9rem}
.metric-value{font-weight:700}
.filters{display:flex;gap:.5rem;margin-bottom:1rem;flex-wrap:wrap}
.filter-btn{padding:.4rem 1rem;border:1px solid var(--border);border-radius:8px;background:var(--bg3);color:var(--text2);cursor:pointer;font-size:.85rem;font-weight:600;transition:all .2s}
.filter-btn.active{border-color:var(--accent);color:var(--accent);background:rgba(0,229,160,.1)}
.positive{color:var(--accent)}.negative{color:var(--danger)}
.chart-container{position:relative;width:100%;height:280px}
.mini-chart{height:60px;width:120px}
@media(max-width:768px){.container{padding:1rem}.grid-2{grid-template-columns:1fr}.header{flex-direction:column;gap:1rem;padding:1rem}.nav{overflow-x:auto;width:100%}th,td{padding:.5rem;font-size:.8rem}}
</style>
</head>
<body>
<div class="header">
<div class="logo">QuantAlpha</div>
<div class="status"><div class="status-dot"></div><span>API Connecte</span></div>
<div class="nav">
<button class="active" onclick="show('dashboard',this)">Dashboard</button>
<button onclick="show('signals',this)">Signaux</button>
<button onclick="show('backtest',this)">Backtest</button>
<button onclick="show('indicators',this)">Indicateurs</button>
</div>
</div>
<div class="container">

<!-- DASHBOARD -->
<div id="dashboard" class="section active">
<div class="stats-grid">
<div class="stat-card"><div class="stat-label">Signaux Actifs</div><div class="stat-value blue" id="d-active">8</div><div class="stat-sub" id="d-active-sub">3 marches</div></div>
<div class="stat-card"><div class="stat-label">Score Moyen</div><div class="stat-value green" id="d-avg">70.2</div><div class="stat-sub">Sur 100 points</div></div>
<div class="stat-card"><div class="stat-label">LONG / SHORT</div><div class="stat-value" id="d-ratio">5 / 3</div><div class="stat-sub">Ratio 1.67</div></div>
<div class="stat-card"><div class="stat-label">Meilleur Score</div><div class="stat-value green" id="d-best">87</div><div class="stat-sub" id="d-best-sub">BTC/USDT</div></div>
<div class="stat-card"><div class="stat-label">Rendement Backtest</div><div class="stat-value green">+18.6%</div><div class="stat-sub">Annualise</div></div>
<div class="stat-card"><div class="stat-label">Sharpe Ratio</div><div class="stat-value green">1.84</div><div class="stat-sub">Risque ajuste</div></div>
</div>
<div class="grid-2">
<div class="card"><h3>Courbe d'Equite</h3><div class="chart-container"><canvas id="equityChart"></canvas></div></div>
<div class="card"><h3>Signaux Recents</h3><table><thead><tr><th>Symbol</th><th>Dir</th><th>Score</th><th>Conf</th></tr></thead><tbody id="dash-signals"></tbody></table></div>
</div>
</div>

<!-- SIGNAUX -->
<div id="signals" class="section">
<div class="filters">
<button class="filter-btn active" onclick="filterSignals('all',this)">Tous</button>
<button class="filter-btn" onclick="filterSignals('crypto',this)">Crypto</button>
<button class="filter-btn" onclick="filterSignals('stocks',this)">Stocks</button>
<button class="filter-btn" onclick="filterSignals('forex',this)">Forex</button>
<button class="filter-btn" onclick="filterSignals('long',this)">LONG</button>
<button class="filter-btn" onclick="filterSignals('short',this)">SHORT</button>
</div>
<div class="card"><table><thead><tr><th>Symbol</th><th>Direction</th><th>Score</th><th>Entree</th><th>SL</th><th>TP</th><th>R:R</th><th>Conf</th><th>TF</th></tr></thead><tbody id="signals-body"></tbody></table></div>
</div>

<!-- BACKTEST -->
<div id="backtest" class="section">
<div class="stats-grid">
<div class="stat-card"><div class="stat-label">Rendement Total</div><div class="stat-value green">+18.6%</div></div>
<div class="stat-card"><div class="stat-label">Win Rate</div><div class="stat-value green">62.3%</div></div>
<div class="stat-card"><div class="stat-label">Sharpe Ratio</div><div class="stat-value green">1.84</div></div>
<div class="stat-card"><div class="stat-label">Max Drawdown</div><div class="stat-value red">-8.2%</div></div>
<div class="stat-card"><div class="stat-label">Profit Factor</div><div class="stat-value green">1.94</div></div>
<div class="stat-card"><div class="stat-label">Trades Total</div><div class="stat-value blue">156</div></div>
</div>
<div class="grid-2">
<div class="card"><h3>Distribution des Trades</h3><div class="chart-container"><canvas id="backtestChart"></canvas></div></div>
<div class="card"><h3>Metriques Detailles</h3>
<div class="metric-row"><span class="metric-label">Trades Gagnants</span><span class="metric-value positive">97 (62.3%)</span></div>
<div class="metric-row"><span class="metric-label">Trades Perdants</span><span class="metric-value negative">59 (37.7%)</span></div>
<div class="metric-row"><span class="metric-label">Gain Moyen</span><span class="metric-value positive">+0.342%</span></div>
<div class="metric-row"><span class="metric-label">Perte Moyenne</span><span class="metric-value negative">-0.189%</span></div>
<div class="metric-row"><span class="metric-label">Retour Moyen/Trade</span><span class="metric-value positive">+0.119%</span></div>
<div class="metric-row"><span class="metric-label">Max Drawdown</span><span class="metric-value negative">-$820</span></div>
<div class="metric-row"><span class="metric-label">Retour Total</span><span class="metric-value positive">+$1,860</span></div>
</div>
</div>
<div class="card" style="margin-top:1.5rem"><h3>Performance Mensuelle (%)</h3><div class="chart-container"><canvas id="monthlyChart" style="height:200px"></canvas></div></div>
</div>

<!-- INDICATEURS -->
<div id="indicators" class="section">
<div class="filters">
<button class="filter-btn active" onclick="loadIndicator('BTC/USDT',this)">BTC/USDT</button>
<button class="filter-btn" onclick="loadIndicator('ETH/USDT',this)">ETH/USDT</button>
<button class="filter-btn" onclick="loadIndicator('SOL/USDT',this)">SOL/USDT</button>
<button class="filter-btn" onclick="loadIndicator('AAPL',this)">AAPL</button>
<button class="filter-btn" onclick="loadIndicator('EUR/USD',this)">EUR/USD</button>
</div>
<div class="stats-grid" id="ind-grid">
<div class="stat-card"><div class="stat-label">RSI (14)</div><div class="stat-value" id="ind-rsi">--</div><div class="stat-sub" id="ind-rsi-sub">Neutre</div></div>
<div class="stat-card"><div class="stat-label">MACD</div><div class="stat-value" id="ind-macd">--</div><div class="stat-sub" id="ind-macd-sub">--</div></div>
<div class="stat-card"><div class="stat-label">ATR (14)</div><div class="stat-value blue" id="ind-atr">--</div></div>
<div class="stat-card"><div class="stat-label">VWAP</div><div class="stat-value" id="ind-vwap">--</div></div>
<div class="stat-card"><div class="stat-label">EMA 20</div><div class="stat-value" id="ind-ema20">--</div></div>
<div class="stat-card"><div class="stat-label">EMA 50</div><div class="stat-value" id="ind-ema50">--</div></div>
</div>
<div class="grid-2">
<div class="card"><h3>Bollinger Bands</h3>
<div class="metric-row"><span class="metric-label">Bande Superieure</span><span class="metric-value" id="ind-boll-up">--</span></div>
<div class="metric-row"><span class="metric-label">Bande Inferieure</span><span class="metric-value" id="ind-boll-down">--</span></div>
<div class="metric-row"><span class="metric-label">Position</span><span class="metric-value" id="ind-boll-pos">--</span></div>
</div>
<div class="card"><h3>Signal Composite</h3>
<div class="metric-row"><span class="metric-label">Prix Actuel</span><span class="metric-value" id="ind-price">--</span></div>
<div class="metric-row"><span class="metric-label">Tendance EMA</span><span class="metric-value" id="ind-trend">--</span></div>
<div class="metric-row"><span class="metric-label">Force RSI</span><span class="metric-value" id="ind-rsi-sig">--</span></div>
</div>
</div>
</div>

</div>
<script>
const SIGNALS_DATA = [{"symbol":"BTC/USDT","market":"crypto","direction":"LONG","score":87,"entry":67234.50,"sl":65800.00,"tp":69800.00,"rr":2.1,"confidence":"HIGH","timeframe":"1h"},{"symbol":"ETH/USDT","market":"crypto","direction":"LONG","score":76,"entry":3456.20,"sl":3380.00,"tp":3620.00,"rr":2.3,"confidence":"HIGH","timeframe":"4h"},{"symbol":"SOL/USDT","market":"crypto","direction":"SHORT","score":72,"entry":148.20,"sl":152.50,"tp":140.00,"rr":1.9,"confidence":"MEDIUM","timeframe":"1h"},{"symbol":"AAPL","market":"stocks","direction":"SHORT","score":68,"entry":189.50,"sl":193.00,"tp":183.00,"rr":1.8,"confidence":"MEDIUM","timeframe":"1d"},{"symbol":"EUR/USD","market":"forex","direction":"LONG","score":64,"entry":1.0845,"sl":1.0800,"tp":1.0920,"rr":1.7,"confidence":"MEDIUM","timeframe":"1h"},{"symbol":"NVDA","market":"stocks","direction":"LONG","score":81,"entry":875.30,"sl":845.00,"tp":920.00,"rr":1.5,"confidence":"HIGH","timeframe":"1d"},{"symbol":"XAU/USD","market":"forex","direction":"LONG","score":59,"entry":2056.40,"sl":2040.00,"tp":2080.00,"rr":1.4,"confidence":"LOW","timeframe":"4h"},{"symbol":"LINK/USDT","market":"crypto","direction":"SHORT","score":53,"entry":14.85,"sl":15.30,"tp":13.90,"rr":2.1,"confidence":"LOW","timeframe":"1h"}];
const EQUITY_DATA = [10000,10045,10020,10080,10150,10120,10200,10280,10350,10320,10400,10450,10520,10480,10600,10720,10680,10750,10800,10760,10850,10920,10880,11000,11050,11100,11060,11150,11200,11180,11250,11300,11260,11350,11400,11380,11450,11500,11460,11520,11580,11600,11550,11620,11680,11700,11650,11720,11780,11800,11750,11820,11860,11800,11850,11900,11860,11920,11960,11860];

function show(id,btn){document.querySelectorAll('.section').forEach(s=>s.classList.remove('active'));document.getElementById(id).classList.add('active');document.querySelectorAll('.nav button').forEach(b=>b.classList.remove('active'));btn.classList.add('active');if(id==='backtest')setTimeout(drawBacktest,50);if(id==='dashboard')setTimeout(drawEquity,50)}

function drawLineChart(canvasId,data,color,label){const c=document.getElementById(canvasId);if(!c)return;const ctx=c.getContext('2d');const dpr=window.devicePixelRatio||1;const rect=c.getBoundingClientRect();c.width=rect.width*dpr;c.height=rect.height*dpr;ctx.scale(dpr,dpr);const w=rect.width,h=rect.height;ctx.clearRect(0,0,w,h);const min=Math.min(...data),max=Math.max(...data),range=max-min||1;ctx.strokeStyle='#1e293b';ctx.lineWidth=1;for(let i=0;i<=4;i++){const y=h-(h/4)*i;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke()}const step=w/(data.length-1);ctx.beginPath();ctx.strokeStyle=color;ctx.lineWidth=2.5;data.forEach((v,i)=>{const x=i*step;const y=h-((v-min)/range)*(h-30)-15;i===0?ctx.moveTo(x,y):ctx.lineTo(x,y)});ctx.stroke();const grad=ctx.createLinearGradient(0,0,0,h);grad.addColorStop(0,color+'30');grad.addColorStop(1,color+'02');ctx.beginPath();data.forEach((v,i)=>{const x=i*step;const y=h-((v-min)/range)*(h-30)-15;i===0?ctx.moveTo(x,y):ctx.lineTo(x,y)});ctx.lineTo(w,h);ctx.lineTo(0,h);ctx.closePath();ctx.fillStyle=grad;ctx.fill();ctx.fillStyle='#8899a6';ctx.font='11px sans-serif';ctx.fillText(label||'',10,15)}

function drawEquity(){drawLineChart('equityChart',EQUITY_DATA,'#00e5a0','Equity Curve')}
function drawBacktest(){const dist=[45,38,22,10,28,18,13];const labels=['0-1R','1-2R','2-3R','3R+','-1-0R','-2--1R','-2R+'];const colors=['#00e5a0','#00b4d8','#00e5a0','#00e5a0','#ff4757','#ff4757','#ff4757'];const c=document.getElementById('backtestChart');if(!c)return;const ctx=c.getContext('2d');const dpr=window.devicePixelRatio||1;const rect=c.getBoundingClientRect();c.width=rect.width*dpr;c.height=rect.height*dpr;ctx.scale(dpr,dpr);const w=rect.width,h=rect.height;ctx.clearRect(0,0,w,h);const barW=Math.min(50,(w-80)/dist.length-10);const max=Math.max(...dist);dist.forEach((v,i)=>{const x=40+i*(barW+15);const bh=(v/max)*(h-50);const y=h-bh-25;const g=ctx.createLinearGradient(0,y,0,h-25);g.addColorStop(0,colors[i]+'cc');g.addColorStop(1,colors[i]+'44');ctx.fillStyle=g;ctx.beginPath();ctx.roundRect(x,y,barW,bh,4);ctx.fill();ctx.fillStyle='#e0e6ed';ctx.font='bold 12px sans-serif';ctx.textAlign='center';ctx.fillText(v,x+barW/2,y-8);ctx.fillStyle='#8899a6';ctx.font='11px sans-serif';ctx.fillText(labels[i],x+barW/2,h-5)})}
function drawMonthly(){const months=['Jan','Fev','Mar','Avr','Mai','Juin','Juil','Aout','Sep','Oct','Nov','Dec'];const vals=[3.2,2.1,-1.4,4.5,2.8,3.1,-0.8,5.2,1.9,-2.3,3.7,2.4];const c=document.getElementById('monthlyChart');if(!c)return;const ctx=c.getContext('2d');const dpr=window.devicePixelRatio||1;const rect=c.getBoundingClientRect();c.width=rect.width*dpr;c.height=rect.height*dpr;ctx.scale(dpr,dpr);const w=rect.width,h=rect.height;ctx.clearRect(0,0,w,h);const barW=Math.min(40,(w-60)/12-8);const absMax=Math.max(...vals.map(Math.abs));vals.forEach((v,i)=>{const x=30+i*(barW+8);const bh=Math.abs(v)/absMax*(h-40);const y=v>=0?h/2-bh:h/2;const color=v>=0?'#00e5a0':'#ff4757';const g=ctx.createLinearGradient(0,y,0,y+bh);g.addColorStop(0,color+'cc');g.addColorStop(1,color+'44');ctx.fillStyle=g;ctx.beginPath();ctx.roundRect(x,y,barW,bh,3);ctx.fill();ctx.fillStyle='#8899a6';ctx.font='10px sans-serif';ctx.textAlign='center';ctx.fillText(months[i],x+barW/2,h-2);ctx.fillStyle='#e0e6ed';ctx.font='bold 10px sans-serif';ctx.fillText((v>0?'+':'')+v+'%',x+barW/2,v>=0?y-6:y+bh+12)})}

function renderSignals(list){const tbody=document.getElementById('signals-body');tbody.innerHTML=list.map(s=>{const conf=s.confidence.toLowerCase();return`<tr><td><strong>${s.symbol}</strong></td><td><span class="badge badge-${s.direction.toLowerCase()}">${s.direction}</span></td><td><div style="display:flex;align-items:center;gap:8px"><div class="score-bar"><div class="score-fill ${conf}"></div></div><strong>${s.score}</strong></div></td><td>${s.entry.toLocaleString()}</td><td style="color:var(--danger)">${s.sl.toLocaleString()}</td><td style="color:var(--accent)">${s.tp.toLocaleString()}</td><td>${s.rr.toFixed(1)}</td><td><span class="badge badge-${conf}">${s.confidence}</span></td><td>${s.timeframe}</td></tr>`}).join('')}
function filterSignals(filter,btn){document.querySelectorAll('.filters .filter-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');const f=filter.toLowerCase();const filtered=f==='all'?SIGNALS_DATA:SIGNALS_DATA.filter(s=>s.market===f||s.direction.toLowerCase()===f);renderSignals(filtered)}

function loadIndicator(sym,btn){if(btn){document.querySelectorAll('#indicators .filter-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active')}const data={"BTC/USDT":{"rsi":58.4,"macd":0.024,"macd_signal":0.018,"atr":142.6,"vwap":67120,"ema_20":66950,"ema_50":65800,"bollinger_upper":68500,"bollinger_lower":65800,"price":67234.50},"ETH/USDT":{"rsi":62.1,"macd":0.031,"macd_signal":0.025,"atr":8.4,"vwap":3450,"ema_20":3440,"ema_50":3380,"bollinger_upper":3520,"bollinger_lower":3380,"price":3456.20},"SOL/USDT":{"rsi":42.3,"macd":-0.015,"macd_signal":-0.008,"atr":4.2,"vwap":150,"ema_20":151,"ema_50":155,"bollinger_upper":155,"bollinger_lower":143,"price":148.20},"AAPL":{"rsi":45.8,"macd":-0.312,"macd_signal":-0.298,"atr":2.8,"vwap":190.20,"ema_20":191.50,"ema_50":195.00,"bollinger_upper":194.00,"bollinger_lower":186.00,"price":189.50},"EUR/USD":{"rsi":51.2,"macd":0.0008,"macd_signal":0.0005,"atr":0.0045,"vwap":1.0840,"ema_20":1.0835,"ema_50":1.0820,"bollinger_upper":1.0870,"bollinger_lower":1.0810,"price":1.0845}}[sym]||{"rsi":50,"macd":0,"macd_signal":0,"atr":10,"vwap":100,"ema_20":100,"ema_50":100,"bollinger_upper":110,"bollinger_lower":90,"price":100};document.getElementById('ind-rsi').textContent=data.rsi;document.getElementById('ind-rsi-sub').textContent=data.rsi>70?'Surachat':data.rsi<30?'Survente':'Neutre';document.getElementById('ind-rsi').className='stat-value '+(data.rsi>70?'green':data.rsi<30?'red':'blue');document.getElementById('ind-macd').textContent=(data.macd>0?'+':'')+data.macd.toFixed(4);document.getElementById('ind-macd-sub').textContent=data.macd>data.macd_signal?'Haussier':'Baissier';document.getElementById('ind-macd').className='stat-value '+(data.macd>data.macd_signal?'green':'red');document.getElementById('ind-atr').textContent=typeof data.atr==='number'&&data.atr<10?data.atr.toFixed(4):data.atr.toLocaleString();document.getElementById('ind-vwap').textContent=data.vwap.toLocaleString();document.getElementById('ind-ema20').textContent=data.ema_20.toLocaleString();document.getElementById('ind-ema50').textContent=data.ema_50.toLocaleString();document.getElementById('ind-boll-up').textContent=data.bollinger_upper.toLocaleString();document.getElementById('ind-boll-down').textContent=data.bollinger_lower.toLocaleString();const mid=(data.bollinger_upper+data.bollinger_lower)/2;const pos=((data.price-data.bollinger_lower)/(data.bollinger_upper-data.bollinger_lower)*100).toFixed(1);document.getElementById('ind-boll-pos').textContent=pos+'% (milieu: '+mid.toLocaleString()+')';document.getElementById('ind-price').textContent=typeof data.price==='number'&&data.price<10?data.price.toFixed(4):data.price.toLocaleString();document.getElementById('ind-trend').textContent=data.ema_20>data.ema_50?'Haussiere':'Baissiere';document.getElementById('ind-trend').className='metric-value '+(data.ema_20>data.ema_50?'positive':'negative');document.getElementById('ind-rsi-sig').textContent=data.rsi>60?'Fort':data.rsi<40?'Faible':'Neutre';document.getElementById('ind-rsi-sig').className='metric-value '+(data.rsi>60?'positive':data.rsi<40?'negative':'')}

// Init
document.addEventListener('DOMContentLoaded',()=>{renderSignals(SIGNALS_DATA);document.getElementById('dash-signals').innerHTML=SIGNALS_DATA.slice(0,5).map(s=>`<tr><td><strong>${s.symbol}</strong></td><td><span class="badge badge-${s.direction.toLowerCase()}">${s.direction}</span></td><td><strong>${s.score}</strong></td><td><span class="badge badge-${s.confidence.toLowerCase()}">${s.confidence}</span></td></tr>`).join('');setTimeout(()=>{drawEquity();drawMonthly()},100)})
window.addEventListener('resize',()=>{const active=document.querySelector('.section.active').id;if(active==='dashboard')drawEquity();if(active==='backtest'){drawBacktest();drawMonthly()}})
</script>
</body>
</html>"""


@app.get("/dashboard", response_class=HTMLResponse)
def dashboard():
    return DASHBOARD_HTML


@app.get("/api/backtest/results")
def backtest_results():
    return {
        "total_trades": 156,
        "winning_trades": 97,
        "losing_trades": 59,
        "win_rate": 0.623,
        "profit_factor": 1.94,
        "sharpe_ratio": 1.84,
        "max_drawdown_pct": 0.082,
        "total_return_pct": 0.186,
        "avg_trade_return": 0.119,
        "avg_win": 0.342,
        "avg_loss": 0.189,
        "equity_curve": EQUITY_CURVE,
        "monthly_returns": {"Jan": 3.2, "Feb": 2.1, "Mar": -1.4, "Apr": 4.5, "May": 2.8, "Jun": 3.1, "Jul": -0.8, "Aug": 5.2, "Sep": 1.9, "Oct": -2.3, "Nov": 3.7, "Dec": 2.4},
        "trades_distribution": {"0-1R": 45, "1-2R": 38, "2-3R": 22, "3R+": 10, "-1-0R": 28, "-2--1R": 18, "-2R+": 13}
    }
