#!/bin/bash
# ============================================================
# Deploy QuantAlpha sur Railway (recommande)
# ============================================================
# Prerequis : npm install -g @railway/cli && railway login

set -e

echo "=== Deploy QuantAlpha sur Railway ==="

# 1. Creer le projet
railway init --name quantalpha

# 2. Ajouter les services
echo "[1/5] Ajout des services..."
railway add --database postgres
echo "   PostgreSQL OK"

railway add --database redis
echo "   Redis OK"

# 3. Variables d'environnement
echo "[2/5] Configuration des variables..."
railway variables set ROOT_PATH=/api
railway variables set POLYGON_API_KEY="${POLYGON_API_KEY:-}"
railway variables set OANDA_API_KEY="${OANDA_API_KEY:-}"
railway variables set TELEGRAM_BOT_TOKEN="${TELEGRAM_BOT_TOKEN:-}"
echo "   Variables OK"

# 4. Deploy API
echo "[3/5] Deploy API..."
railway up --detach

# 5. Health check
echo "[4/5] Health check..."
API_URL=$(railway domain)
sleep 10
curl -sf "${API_URL}/api/health" && echo "   API saine" || echo "   WARNING: Health check failed"

# 6. Deploy Dashboard (static site)
echo "[5/5] Deploy Dashboard..."
cd dashboard
railway up --service quantalpha-dashboard
echo ""
echo "=== Deploy termine ==="
echo "API:    ${API_URL}/api/docs"
echo "Dashboard: $(railway domain --service quantalpha-dashboard)"
