import { Activity, TrendingUp, TrendingDown, BarChart3 } from 'lucide-react'

const MOCK_SIGNALS = [
  { symbol: 'BTC/USDT', market: 'crypto', direction: 'LONG' as const, score: 87, entry_price: 67234, stop_loss: 65800, take_profit: 69800, risk_reward: 2.1, confidence: 'HIGH' as const, timeframe: '1h', timestamp: '2 min' },
  { symbol: 'ETH/USDT', market: 'crypto', direction: 'LONG' as const, score: 76, entry_price: 3456, stop_loss: 3380, take_profit: 3620, risk_reward: 2.3, confidence: 'HIGH' as const, timeframe: '4h', timestamp: '5 min' },
  { symbol: 'AAPL', market: 'stocks', direction: 'SHORT' as const, score: 72, entry_price: 189.50, stop_loss: 193.00, take_profit: 183.00, risk_reward: 1.8, confidence: 'MEDIUM' as const, timeframe: '1d', timestamp: '12 min' },
  { symbol: 'EUR/USD', market: 'forex', direction: 'LONG' as const, score: 68, entry_price: 1.0845, stop_loss: 1.0800, take_profit: 1.0920, risk_reward: 1.7, confidence: 'MEDIUM' as const, timeframe: '1h', timestamp: '18 min' },
]

export default function DashboardPage() {
  const longCount = MOCK_SIGNALS.filter(s => s.direction === 'LONG').length
  const shortCount = MOCK_SIGNALS.filter(s => s.direction === 'SHORT').length
  const avgScore = (MOCK_SIGNALS.reduce((a, s) => a + s.score, 0) / MOCK_SIGNALS.length).toFixed(1)

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-navy-700">Tableau de bord</h1>
        <div className="flex items-center gap-2 mt-1">
          <p className="text-navy-400">Vue d'ensemble des marches</p>
          <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-green-100 text-green-700">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" /> API OK
          </span>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-xl border border-navy-200 p-4">
          <div className="flex items-center justify-between mb-2"><span className="text-xs text-navy-400 uppercase">Signaux actifs</span><BarChart3 size={18} className="text-navy-400" /></div>
          <div className="font-mono text-2xl font-bold text-navy-700">{MOCK_SIGNALS.length}</div>
        </div>
        <div className="bg-white rounded-xl border border-green-200 p-4">
          <div className="flex items-center justify-between mb-2"><span className="text-xs text-green-600 uppercase">LONG</span><TrendingUp size={18} className="text-green-500" /></div>
          <div className="font-mono text-2xl font-bold text-green-600">{longCount}</div>
        </div>
        <div className="bg-white rounded-xl border border-red-200 p-4">
          <div className="flex items-center justify-between mb-2"><span className="text-xs text-red-600 uppercase">SHORT</span><TrendingDown size={18} className="text-red-500" /></div>
          <div className="font-mono text-2xl font-bold text-red-600">{shortCount}</div>
        </div>
        <div className="bg-white rounded-xl border border-gold-200 p-4">
          <div className="flex items-center justify-between mb-2"><span className="text-xs text-gold-600 uppercase">Score moyen</span><Activity size={18} className="text-gold-500" /></div>
          <div className="font-mono text-2xl font-bold text-gold-500">{avgScore}</div>
        </div>
      </div>

      <h2 className="text-lg font-semibold text-navy-700 mb-3">Meilleurs signaux (score ≥ 60)</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {MOCK_SIGNALS.filter(s => s.score >= 60).map((signal, i) => (
          <div key={i} className={`rounded-xl border bg-white p-4 shadow-sm ${signal.direction === 'LONG' ? 'border-green-200' : 'border-red-200'}`}>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="font-mono text-lg font-bold text-navy-700">{signal.symbol}</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-navy-100 text-navy-600 uppercase">{signal.market}</span>
              </div>
              <div className={`flex items-center gap-1 px-3 py-1 rounded-full text-sm font-semibold ${signal.direction === 'LONG' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'}`}>
                {signal.direction === 'LONG' ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                {signal.direction}
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2 mb-3">
              <div className="bg-navy-50 rounded-lg p-2 text-center">
                <div className="text-xs text-navy-400">Entry</div>
                <div className="font-mono text-sm font-semibold text-navy-700">{signal.entry_price.toLocaleString()}</div>
              </div>
              <div className="bg-red-50 rounded-lg p-2 text-center">
                <div className="text-xs text-red-400">SL</div>
                <div className="font-mono text-sm font-semibold text-red-500">{signal.stop_loss.toLocaleString()}</div>
              </div>
              <div className="bg-green-50 rounded-lg p-2 text-center">
                <div className="text-xs text-green-400">TP</div>
                <div className="font-mono text-sm font-semibold text-green-500">{signal.take_profit.toLocaleString()}</div>
              </div>
            </div>
            <div className="flex items-center justify-between text-xs text-navy-400 pt-2 border-t border-navy-100">
              <span>R:R {signal.risk_reward}</span>
              <span>{signal.confidence}</span>
              <span>{signal.timeframe}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
