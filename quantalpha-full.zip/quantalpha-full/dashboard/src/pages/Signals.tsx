import { useState } from 'react'
import { TrendingUp, TrendingDown, BarChart3, Target, Shield, Clock, Filter, Bitcoin, DollarSign } from 'lucide-react'

const ALL_SIGNALS = [
  { symbol: 'BTC/USDT', market: 'crypto', direction: 'LONG' as const, score: 87, entry: 67234, sl: 65800, tp: 69800, rr: 2.1, confidence: 'HIGH' as const, tf: '1h', time: '2 min' },
  { symbol: 'ETH/USDT', market: 'crypto', direction: 'LONG' as const, score: 76, entry: 3456, sl: 3380, tp: 3620, rr: 2.3, confidence: 'HIGH' as const, tf: '4h', time: '5 min' },
  { symbol: 'AAPL', market: 'stocks', direction: 'SHORT' as const, score: 72, entry: 189.50, sl: 193.00, tp: 183.00, rr: 1.8, confidence: 'MEDIUM' as const, tf: '1d', time: '12 min' },
  { symbol: 'EUR/USD', market: 'forex', direction: 'LONG' as const, score: 68, entry: 1.0845, sl: 1.0800, tp: 1.0920, rr: 1.7, confidence: 'MEDIUM' as const, tf: '1h', time: '18 min' },
  { symbol: 'SOL/USDT', market: 'crypto', direction: 'SHORT' as const, score: 64, entry: 148.20, sl: 152.50, tp: 140.00, rr: 1.9, confidence: 'MEDIUM' as const, tf: '1h', time: '25 min' },
  { symbol: 'TSLA', market: 'stocks', direction: 'LONG' as const, score: 58, entry: 245.80, sl: 238.00, tp: 260.00, rr: 1.9, confidence: 'LOW' as const, tf: '1d', time: '32 min' },
  { symbol: 'GBP/USD', market: 'forex', direction: 'SHORT' as const, score: 55, entry: 1.2680, sl: 1.2730, tp: 1.2580, rr: 2.0, confidence: 'LOW' as const, tf: '4h', time: '41 min' },
  { symbol: 'NVDA', market: 'stocks', direction: 'LONG' as const, score: 82, entry: 875.30, sl: 855.00, tp: 915.00, rr: 2.0, confidence: 'HIGH' as const, tf: '1d', time: '1 h' },
]

const MARKETS = [
  { value: 'all', label: 'Tous', icon: <Filter size={14} /> },
  { value: 'crypto', label: 'Crypto', icon: <Bitcoin size={14} /> },
  { value: 'stocks', label: 'Actions', icon: <BarChart3 size={14} /> },
  { value: 'forex', label: 'Forex', icon: <DollarSign size={14} /> },
]

const TFS = ['all', '1m', '5m', '15m', '1h', '4h', '1d']

export default function SignalsPage() {
  const [market, setMarket] = useState('all')
  const [tf, setTf] = useState('all')
  const [minScore, setMinScore] = useState(50)

  const filtered = ALL_SIGNALS.filter(s => {
    if (market !== 'all' && s.market !== market) return false
    if (tf !== 'all' && s.tf !== tf) return false
    return s.score >= minScore
  })

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold text-navy-700 mb-1">Signaux de Trading</h1>
      <p className="text-navy-400 mb-6">Signaux multicriteres mis a jour en temps reel</p>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl border border-navy-200 p-4 space-y-4">
            <div>
              <label className="text-xs font-medium text-navy-400 uppercase mb-2 block">Marche</label>
              <div className="flex flex-wrap gap-2">
                {MARKETS.map(m => (
                  <button key={m.value} onClick={() => setMarket(m.value)}
                    className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${market === m.value ? 'bg-navy-500 text-white' : 'bg-navy-50 text-navy-600'}`}>
                    {m.icon} {m.label}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-navy-400 uppercase mb-2 block">Timeframe</label>
              <div className="flex flex-wrap gap-2">
                {TFS.map(t => (
                  <button key={t} onClick={() => setTf(t)}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${tf === t ? 'bg-gold-500 text-white' : 'bg-navy-50 text-navy-600'}`}>
                    {t === 'all' ? 'Tous' : t}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-navy-400 uppercase mb-2 block">Score min: <span className="text-navy-700 font-bold">{minScore}</span></label>
              <input type="range" min={0} max={100} step={5} value={minScore} onChange={e => setMinScore(Number(e.target.value))} className="w-full accent-navy-500" />
            </div>
          </div>
        </div>

        <div className="lg:col-span-3">
          {filtered.length === 0 ? (
            <div className="flex items-center justify-center h-64 bg-navy-50 rounded-xl text-navy-400">Aucun signal ne correspond aux filtres</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filtered.map((s, i) => (
                <div key={i} className={`rounded-xl border bg-white p-4 shadow-sm ${s.direction === 'LONG' ? 'border-green-200' : 'border-red-200'}`}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-lg font-bold text-navy-700">{s.symbol}</span>
                      <span className="text-xs px-2 py-0.5 rounded-full bg-navy-100 text-navy-600 uppercase">{s.market}</span>
                    </div>
                    <div className={`flex items-center gap-1 px-3 py-1 rounded-full text-sm font-semibold ${s.direction === 'LONG' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'}`}>
                      {s.direction === 'LONG' ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                      {s.direction}
                    </div>
                  </div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2"><BarChart3 size={16} className={s.score >= 70 ? 'text-green-500' : s.score >= 50 ? 'text-gold-500' : 'text-yellow-500'} /><span className="text-sm text-navy-500">Score</span></div>
                    <span className={`font-mono text-2xl font-bold ${s.score >= 70 ? 'text-green-500' : s.score >= 50 ? 'text-gold-500' : 'text-yellow-500'}`}>{s.score}/100</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 mb-3">
                    <div className="bg-navy-50 rounded-lg p-2 text-center"><div className="text-xs text-navy-400">Entry</div><div className="font-mono text-sm font-semibold text-navy-700">{s.entry.toLocaleString()}</div></div>
                    <div className="bg-red-50 rounded-lg p-2 text-center"><div className="text-xs text-red-400">SL</div><div className="font-mono text-sm font-semibold text-red-500">{s.sl.toLocaleString()}</div></div>
                    <div className="bg-green-50 rounded-lg p-2 text-center"><div className="text-xs text-green-400">TP</div><div className="font-mono text-sm font-semibold text-green-500">{s.tp.toLocaleString()}</div></div>
                  </div>
                  <div className="flex items-center justify-between text-xs text-navy-400 pt-2 border-t border-navy-100">
                    <span className="flex items-center gap-1"><Target size={12} /> R:R {s.rr}</span>
                    <span className="flex items-center gap-1"><Shield size={12} /> {s.confidence}</span>
                    <span className="flex items-center gap-1"><Clock size={12} /> {s.tf}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
