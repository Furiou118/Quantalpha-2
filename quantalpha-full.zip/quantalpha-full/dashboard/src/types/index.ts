export type Direction = 'LONG' | 'SHORT'
export type Timeframe = '1m' | '5m' | '15m' | '1h' | '4h' | '1d'
export type Market = 'crypto' | 'stocks' | 'forex'

export interface Signal {
  symbol: string
  market: Market
  direction: Direction
  score: number
  entry_price: number
  stop_loss: number
  take_profit: number
  risk_reward: number
  confidence: 'LOW' | 'MEDIUM' | 'HIGH'
  timeframe: Timeframe
  timestamp: string
}

export interface BacktestResult {
  total_trades: number
  winning_trades: number
  losing_trades: number
  win_rate: number
  profit_factor: number
  sharpe_ratio: number
  max_drawdown: number
  max_drawdown_pct: number
  total_return: number
  total_return_pct: number
  equity_curve: Array<{ timestamp: string; equity: number }>
}

export interface HealthStatus {
  status: string
  version: string
  connectors: Record<string, string>
  redis: string
  timestamp: string
}
