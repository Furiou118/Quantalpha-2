from abc import ABC, abstractmethod
from datetime import datetime
from typing import Dict, List, Optional
import pandas as pd


class BaseMarketConnector(ABC):
    """Classe abstraite pour tous les connecteurs de marche."""

    NAME: str = ""
    DISPLAY_NAME: str = ""

    @abstractmethod
    async def fetch_ohlcv(
        self, symbol: str, timeframe: str = "1h",
        since: Optional[datetime] = None,
        until: Optional[datetime] = None,
        limit: int = 500,
    ) -> pd.DataFrame:
        """Recupere les donnees OHLCV."""

    @abstractmethod
    async def fetch_all(
        self, symbols: Optional[List[str]] = None,
        timeframe: str = "1h", limit: int = 500,
    ) -> Dict[str, pd.DataFrame]:
        """Recupere les donnees pour tous les symboles."""

    @property
    @abstractmethod
    def symbols(self) -> List[str]:
        """Liste des symboles disponibles."""

    @property
    @abstractmethod
    def timeframes(self) -> List[str]:
        """Liste des timeframes disponibles."""
