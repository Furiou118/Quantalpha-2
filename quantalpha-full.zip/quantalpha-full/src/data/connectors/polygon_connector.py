import asyncio
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import httpx
import pandas as pd
from tenacity import retry, stop_after_attempt, wait_exponential
from .base_connector import BaseMarketConnector
from .rate_limiter import RateLimiter

TIMEFRAME_MAP = {
    "1m": (1, "minute"), "5m": (5, "minute"), "15m": (15, "minute"),
    "1h": (1, "hour"), "1d": (1, "day"),
}

DEFAULT_SYMBOLS = ["AAPL", "MSFT", "NVDA", "TSLA", "SPY"]


class PolygonConnector(BaseMarketConnector):
    NAME = "stocks"
    DISPLAY_NAME = "US Stocks (Polygon.io)"

    def __init__(self, api_key: Optional[str] = None) -> None:
        self._api_key = api_key or os.environ.get("POLYGON_API_KEY", "")
        if not self._api_key:
            raise RuntimeError("POLYGON_API_KEY requise")
        self._base_url = "https://api.polygon.io/v2/aggs/ticker"
        self._client: Optional[httpx.AsyncClient] = None
        self._limiter = RateLimiter(max_requests=5, window_sec=60.0)

    async def __aenter__(self):
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(30.0, connect=10.0),
            headers={"Authorization": f"Bearer {self._api_key}"},
        )
        return self

    async def __aexit__(self, *_) -> None:
        if self._client:
            await self._client.aclose()

    @property
    def symbols(self) -> List[str]:
        return DEFAULT_SYMBOLS

    @property
    def timeframes(self) -> List[str]:
        return list(TIMEFRAME_MAP.keys())

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10))
    async def fetch_ohlcv(self, symbol, timeframe="1h", since=None, until=None, limit=500):
        if not self._client:
            raise RuntimeError("Connector non ouvert")
        if timeframe not in TIMEFRAME_MAP:
            raise ValueError(f"Timeframe inconnu: {timeframe}")
        mult, span = TIMEFRAME_MAP[timeframe]
        if until is None:
            until = datetime.utcnow()
        if since is None:
            since = until - timedelta(days=30)
        await self._limiter.acquire()
        url = f"{self._base_url}/{symbol}/range/{mult}/{span}/{since.strftime('%Y-%m-%d')}/{until.strftime('%Y-%m-%d')}"
        resp = await self._client.get(url, params={"adjusted": "true", "sort": "asc", "limit": min(limit, 50000)})
        resp.raise_for_status()
        data = resp.json()
        if data.get("status") != "OK" or "results" not in data:
            return pd.DataFrame(columns=["open", "high", "low", "close", "volume"])
        df = pd.DataFrame(data["results"])
        df = df.rename(columns={"t": "timestamp", "o": "open", "h": "high", "l": "low", "c": "close", "v": "volume"})
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        df = df.set_index("timestamp")[["open", "high", "low", "close", "volume"]].astype(float)
        return df

    async def fetch_all(self, symbols=None, timeframe="1h", since=None, until=None, limit=500):
        targets = symbols or self.symbols
        results = await asyncio.gather(*[self.fetch_ohlcv(s, timeframe, since, until, limit) for s in targets], return_exceptions=True)
        return {s: r for s, r in zip(targets, results) if not isinstance(r, Exception)}
