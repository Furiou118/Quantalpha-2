from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
import random

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

SIGNALS = [
    {"symbol":"BTC/USDT","direction":"LONG","score":87,"entry":67234,"sl":65800,"tp":69800,"rr":2.1,"confidence":"HIGH","timeframe":"1h"},
    {"symbol":"ETH/USDT","direction":"LONG","score":76,"entry":3456,"sl":3380,"tp":3620,"rr":2.3,"confidence":"HIGH","timeframe":"4h"},
    {"symbol":"AAPL","direction":"SHORT","score":72,"entry":189.50,"sl":193.00,"tp":183.00,"rr":1.8,"confidence":"MEDIUM","timeframe":"1d"},
    {"symbol":"EUR/USD","direction":"LONG","score":68,"entry":1.0845,"sl":1.0800,"tp":1.0920,"rr":1.7,"confidence":"MEDIUM","timeframe":"1h"},
    {"symbol":"SOL/USDT","direction":"SHORT","score":64,"entry":148.20,"sl":152.50,"tp":140.00,"rr":1.9,"confidence":"MEDIUM","timeframe":"1h"},
]

@app.get("/")
def root():
    return {"message": "QuantAlpha API", "status": "ok", "version": "2.0.0"}

@app.get("/health")
def health():
    return {"status": "ok", "redis": "connected", "timestamp": "2025-01-15T10:00:00"}

@app.get("/api/signals")
def get_signals():
    return SIGNALS

@app.get("/api/indicators/{symbol}")
def get_indicators(symbol: str):
    return {"symbol": symbol, "rsi": round(30 + random.random()*40, 1), "macd": round(random.random()*0.1, 4), "atr": round(100 + random.random()*100, 1), "vwap": 67120}

@app.post("/api/backtest")
def run_backtest():
    return {"total_trades":156,"winning_trades":97,"losing_trades":59,"win_rate":0.623,"profit_factor":1.94,"sharpe_ratio":1.84,"max_drawdown_pct":0.082,"total_return_pct":0.186}

# Dashboard HTML
@app.get("/dashboard", response_class=HTMLResponse)
def dashboard():
    return open("src/dashboard.html").read()
